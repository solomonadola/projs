package astuclassmangementsystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Registration implements ActionListener {
	MainWindow mf = new MainWindow();
	private JTextField naf = new JTextField();
	private JTextField idf = new JTextField();
	private JTextField sef = new JTextField();
	private JTextField grf = new JTextField();
	Home nh = new Home();
	private JLabel bg;
	ImageIcon ic;
	private JButton regibtn = new JButton("Register");
	private JComboBox<?> year;
	private JComboBox<?> dept;
	private JComboBox<?> ty;
	private JComboBox<?> sx;

	Registration() {
		ic = new ImageIcon(getClass().getResource("registrationbg.png"));
		bg = new JLabel(ic);
		bg.setSize(800, 860);
		mf.remove(mf.jl);
		mf.repaint();
		mf.add(bg);
		sef.setBounds(200, 235, 230, 30);
		naf.setBounds(305, 155, 305, 40);
		idf.setBounds(305, 230, 305, 40);
		sef.setBounds(305, 373, 305, 40);
		grf.setBounds(305, 450, 305, 40);
		naf.setForeground(Color.BLUE.brighter());
		naf.setFont(new Font("serif", Font.BOLD, 18));
		idf.setForeground(Color.BLUE.brighter());
		idf.setFont(new Font("serif", Font.BOLD, 18));
		sef.setForeground(Color.BLUE.brighter());
		sef.setFont(new Font("serif", Font.BOLD, 18));
		grf.setForeground(Color.BLUE.brighter());
		grf.setFont(new Font("serif", Font.BOLD, 18));
		String[] type = { "Regular", "Add" };
		String[] sex = { "M", "F" };
		String[] dep = { "CSE", "ECE", "EPCE" };
		String[] yr = { "III", "I", "II", "IV", "V" };
		year = new JComboBox<>(yr);
		dept = new JComboBox<>(dep);
		ty = new JComboBox<>(type);
		sx = new JComboBox<>(sex);
		sx.setBounds(305, 300, 305, 40);
		ty.setBounds(305, 613, 305, 40);
		year.setBounds(305, 691, 305, 40);
		dept.setBounds(305, 527, 305, 40);
		regibtn.setBounds(500, 750, 120, 45);
		year.setForeground(Color.BLUE.brighter());
		year.setFont(new Font("serif", Font.BOLD, 18));
		dept.setForeground(Color.BLUE.brighter());
		dept.setFont(new Font("serif", Font.BOLD, 18));
		ty.setForeground(Color.BLUE.brighter());
		ty.setFont(new Font("serif", Font.BOLD, 18));
		sx.setForeground(Color.BLUE.brighter());
		sx.setFont(new Font("serif", Font.BOLD, 18));
		bg.add(naf);
		bg.add(idf);
		bg.add(sef);
		bg.add(grf);
		bg.add(regibtn);
		bg.add(year);
		bg.add(dept);
		bg.add(sx);
		bg.add(ty);
		nh.setBounds(20, 20, 100, 40);
		bg.add(nh);
		regibtn.addActionListener(this);
		nh.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == nh) {
			mf.dispose();
		}
		if (e.getSource() == regibtn) {
			String url = "jdbc:mysql://localhost:3306/CMS";
			String username = "root";
			String password = "root";
			Connection con = null;
			PreparedStatement preparedStmt = null;
			String nam, id, sex, ye, typ, sec, gr, dep;
			nam = naf.getText();
			id = idf.getText();
			sex = sx.getSelectedItem().toString();
			ye = year.getSelectedItem().toString();
			typ = ty.getSelectedItem().toString();
			sec = sef.getText();
			gr = grf.getText();
			dep = dept.getSelectedItem().toString();
			try {
				con = DriverManager.getConnection(url, username, password);
				String query = " insert into studenttable(name,id,sex,department,type,year,grou,section) values (?, ?, ?, ?, ?,?,?,?)";
				preparedStmt = con.prepareStatement(query);
				preparedStmt.setString(1, nam);
				preparedStmt.setString(2, id);
				preparedStmt.setString(3, sex);
				preparedStmt.setString(4, dep);
				preparedStmt.setString(5, typ);
				preparedStmt.setString(6, ye);
				preparedStmt.setString(7, gr);
				preparedStmt.setString(8, sec);
				preparedStmt.execute();
				preparedStmt.close();
				con.close();
				JOptionPane.showMessageDialog(mf, "registration success", "info", JOptionPane.INFORMATION_MESSAGE);
			} catch (SQLIntegrityConstraintViolationException ex) {
				JOptionPane.showMessageDialog(mf, "something is wrong my be duplicate id", "info",
						JOptionPane.WARNING_MESSAGE);
			} catch (SQLException exd) {
				System.out.println(exd);
				JOptionPane.showMessageDialog(mf,
						"something is wrong you must fill all the information\n or you have inserted a wrong data",
						"info", JOptionPane.WARNING_MESSAGE);
			} catch (Exception exd) {
				JOptionPane.showMessageDialog(mf, "something is wrong with database can't connect with database",
						"info", JOptionPane.WARNING_MESSAGE);
			}

		}
	}

}
