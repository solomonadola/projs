package astuclassmangementsystem;

import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

class MainWindow extends JFrame {
	private static final long serialVersionUID = 1L;
	ImageIcon ic;
	JLabel jl;

	public MainWindow() {
		super("Class Mangement System(CMS)");
		ic = new ImageIcon(getClass().getResource("mainwindowbg.png"));
		jl = new JLabel(ic);
		jl.setSize(800, 860);
		add(jl);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new FlowLayout());
		setSize(820, 860);
		setLocationRelativeTo(null);
	}

}
