package astuclassmangementsystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Attendance implements ActionListener {
	MainWindow mf = new MainWindow();;
	JTable att;
	Home hm = new Home();
	private JScrollPane jsp = new JScrollPane(att);
	private String url = "jdbc:mysql://localhost:3306/CMS";
	private String username = "root";
	private String password = "root";
	private Connection con = null;
	private Statement st = null;
	private PreparedStatement pst = null;
	int  sta1=0;
	public Attendance() {
		att = new JTable(41, 6) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		att.setBounds(0, 0, 800, 860);
		att.setBackground(Color.black.darker());
		att.setForeground(Color.white.brighter());
		att.setFont(new Font("arial", Font.BOLD, 13));
		att.setValueAt("No", 0, 0);
		att.setValueAt("Name", 0, 1);
		att.setValueAt("Id", 0, 2);
		att.setValueAt("Present", 0, 3);
		att.setValueAt("Absent", 0, 4);
		att.setValueAt("undo", 0, 5);
		att.getColumnModel().getColumn(1).setPreferredWidth(500);
		att.getColumnModel().getColumn(2).setPreferredWidth(250);
		mf.jl.add(att);
		mf.jl.add(jsp);
		att.add(hm);
		
		att.addMouseListener(new java.awt.event.MouseAdapter()

		{

			public void mouseClicked(java.awt.event.MouseEvent e)

			{

				int row = att.rowAtPoint(e.getPoint());

				int col = att.columnAtPoint(e.getPoint());
				

				if (col == 4 && row != 0) {
					try {
						con = DriverManager.getConnection(url, username, password);
						st = con.createStatement();
						pst = con.prepareStatement("update studenttable set attendance=attendance+1 where id=?");
						pst.setString(1, (String) att.getValueAt(row, 2));
						pst.execute();
						con.close();
						st.close();
						JOptionPane.showMessageDialog(mf, att.getValueAt(row, 1) + " " + "is absent today");
						sta1=row;
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(null, "something wents wrong can't connect to database.", "Alert",
								JOptionPane.WARNING_MESSAGE);
					}
				} else if (col == 5 && row != 0) {
					try {
						con = DriverManager.getConnection(url, username, password);
						st = con.createStatement();
						if(sta1==row) {
							pst = con.prepareStatement("update studenttable set attendance=attendance-1 where id=?");
							pst.setString(1, (String) att.getValueAt(row, 2));
							pst.execute();
							con.close();
							st.close();
							
						}
						

					} catch (Exception ex) {
						JOptionPane.showMessageDialog(null, "something wents wrong can't connect to database.", "Alert",
								JOptionPane.WARNING_MESSAGE);
					}
				}
			}

		}

		);

		hm.addActionListener(this);
		int kls = 1;
		while (kls < 40) {
			att.setValueAt(kls, kls, 0);
			kls++;
		}
		try {
			con = DriverManager.getConnection(url, username, password);
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from studenttable order by name");
			int k = 0;
			while (rs.next()) {
				k++;
				att.setValueAt(rs.getString("name"), k, 1);
				att.setValueAt(rs.getString("id"), k, 2);

			}
			con.close();
			st.close();
			rs.close();
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "something wents wrong can't connect to database.", "Alert",
					JOptionPane.WARNING_MESSAGE);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == hm) {
			mf.dispose();
		}
	}
}
