package astuclassmangementsystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

class Delete implements ActionListener, MouseListener {
	MainWindow mf = new MainWindow();
	Home hm = new Home();
	private JTextField df = new JTextField("enter id here to delete a student");
	private JButton dbtn = new JButton("delete");

	public Delete() {

		df.setBounds(250, 300, 300, 40);
		dbtn.setBounds(350, 380, 104, 40);
		df.setForeground(Color.red);
		df.setFont(new Font("arial", Font.BOLD, 18));
		mf.jl.add(df);
		mf.jl.add(dbtn);
		dbtn.addActionListener(this);
		df.addMouseListener(this);
		mf.jl.add(hm);
		hm.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == hm) {
			mf.dispose();
		}
		if (e.getSource() == dbtn) {
			String url = "jdbc:mysql://localhost:3306/CMS";
			String username = "root";
			String password = "root";
			Connection con = null;
			PreparedStatement preparedStmt = null;
			try {
				con = DriverManager.getConnection(url, username, password);
				String query = " delete from studenttable where id=?",
						query2 = "select name from studenttable where id=?";
				preparedStmt = con.prepareStatement(query2);
				preparedStmt.setString(1, df.getText());
				ResultSet rs = preparedStmt.executeQuery();
				boolean b = false;
				String rss = null;
				if (rs.next()) {
					rss = rs.getString("name");
					int a = JOptionPane.showConfirmDialog(mf, "Are you sure to delete ? " + rss + " from your class");
					if (a == JOptionPane.YES_OPTION) {
						b = true;
					}
				} else {
					JOptionPane.showMessageDialog(mf, "no one  has this id in this class ", "alert",
							JOptionPane.WARNING_MESSAGE);
				}
				if (b) {
					preparedStmt = con.prepareStatement(query);
					preparedStmt.setString(1, df.getText());
					preparedStmt.execute();
					JOptionPane.showMessageDialog(mf, "deletion  success", "info", JOptionPane.INFORMATION_MESSAGE);
					b = false;
				}
				preparedStmt.close();
				con.close();

			}

			catch (Exception exd) {
				JOptionPane.showMessageDialog(mf, "something is wrong with database can't connect with database",
						"info", JOptionPane.WARNING_MESSAGE);

			}
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		df.setText(null);
		df.removeMouseListener(this);

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}
}
