package astuclassmangementsystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JScrollPane;
import javax.swing.JTable;

public class StudentInfo implements ActionListener {
	MainWindow mf = new MainWindow();;
	JTable att;
	JScrollPane jsp = new JScrollPane(att);
	Home hm = new Home();

	StudentInfo() {
		att = new JTable(41, 5) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int row, int column) {

				return false;
			};
		};
		att.setBounds(0, 0, 800, 860);
		att.setBackground(Color.black.darker());
		att.setForeground(Color.white);
		att.setFont(new Font("arial", Font.ROMAN_BASELINE, 16));
		att.setValueAt("No", 0, 0);
		att.setValueAt("Name", 0, 1);
		att.setValueAt("Id", 0, 2);
		att.setValueAt("Absent day", 0, 3);
		att.setValueAt("total mark", 0, 4);
		att.getColumnModel().getColumn(0).setPreferredWidth(2);
		att.getColumnModel().getColumn(1).setPreferredWidth(250);
		att.getColumnModel().getColumn(2).setPreferredWidth(150);
		int kl = 1;
		while (kl < 41) {
			att.setValueAt(kl, kl, 0);
			kl++;
		}
		mf.jl.add(att);
		mf.jl.add(jsp);
		att.add(hm);
		hm.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == hm) {
			mf.dispose();
		}
	}
}
