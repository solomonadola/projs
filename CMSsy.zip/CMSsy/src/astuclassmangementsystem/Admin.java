
package astuclassmangementsystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Admin implements ActionListener {
	static MainWindow jf, mf;
	private JPasswordField jpf = new JPasswordField();
	private JTextField jtf = new JTextField();
	private JButton lgbtn = new JButton("login");
	private ImageIcon ic;
	private JLabel bg;
	private JButton crbtn = new JButton("create");
	private JTextField usna, cusna;
	private JPasswordField pas, cpas;

	public Admin() {
		String url = "jdbc:mysql://localhost:3306";
		String username = "root";
		String password = "root";
		Connection con = null;
		Statement st = null;
		try {
			con = DriverManager.getConnection(url, username, password);
			st = con.createStatement();
			st.executeUpdate("create database CMS");
			st.close();
			url = "jdbc:mysql://localhost:3306/CMS";
			con = DriverManager.getConnection(url, username, password);
			st = con.createStatement();
			st.executeUpdate(
					"CREATE TABLE Admintable ( username VARCHAR(16), password VARCHAR(16), PRIMARY KEY (username))");
			st.executeUpdate(
					"CREATE TABLE studenttable (name VARCHAR(30),id VARCHAR(12) PRIMARY KEY,sex CHAR,department VARCHAR(10),type VARCHAR(10), year VARCHAR(3), grou INT default 0, section INT,"
							+ "quiz INT  default 0,  assignment INT  default 0,  mid INT  default 0,   final INT  default 0, attendance int  default 0)");
			st.executeUpdate("CREATE TABLE lastsession ( las VARCHAR(200))");
			st.close();

			mf = new MainWindow();

			JLabel jlf = new JLabel("welcome to CMS this is your first time please create a user for this system");
			JLabel usn = new JLabel("create username");
			JLabel cusn = new JLabel("confirm username");
			JLabel pasl = new JLabel("create password");
			JLabel cpasl = new JLabel("confirm password");
			usna = new JTextField();
			cusna = new JTextField();
			cpas = new JPasswordField();
			pas = new JPasswordField();
			jlf.setBounds(70, 40, 680, 50);
			jlf.setForeground(Color.ORANGE.brighter());
			jlf.setFont(new Font("arial", Font.BOLD, 18));
			usn.setBounds(260, 145, 305, 40);
			usn.setForeground(Color.PINK);
			usn.setFont(new Font("arial", Font.BOLD, 18));
			cusn.setBounds(260, 225, 305, 40);
			cusn.setForeground(Color.PINK);
			cusn.setFont(new Font("arial", Font.BOLD, 18));
			pasl.setBounds(260, 305, 305, 40);
			pasl.setForeground(Color.PINK);
			pasl.setFont(new Font("arial", Font.BOLD, 18));
			cpasl.setBounds(260, 385, 305, 40);
			cpasl.setForeground(Color.PINK);
			cpasl.setFont(new Font("arial", Font.BOLD, 18));
			usna.setBounds(260, 180, 305, 40);
			cusna.setBounds(260, 260, 305, 40);
			pas.setBounds(260, 340, 305, 40);
			cpas.setBounds(260, 420, 305, 40);
			crbtn.setBounds(370, 500, 100, 30);
			crbtn.setFont(new Font("arial", Font.BOLD, 20));
			crbtn.setForeground(new Color(138, 54, 15));
			mf.jl.add(usna);
			mf.jl.add(cusna);
			mf.jl.add(pas);
			mf.jl.add(cpas);
			mf.jl.add(usn);
			mf.jl.add(cusn);
			mf.jl.add(cpasl);
			mf.jl.add(pasl);
			mf.jl.add(jlf);
			mf.jl.add(crbtn);
			mf.repaint();
			crbtn.addActionListener(this);

		} catch (SQLException ex) {
			jf = new MainWindow();
			jf.setVisible(false);
			ic = new ImageIcon(getClass().getResource("login.png"));
			bg = new JLabel(ic);
			bg.setSize(800, 860);
			jf.remove(jf.jl);
			jf.repaint();
			jf.add(bg);
			jtf.setFont(new Font("arial", Font.BOLD, 18));
			jtf.setBounds(317, 240, 278, 42);
			jpf.setBounds(317, 335, 278, 42);
			lgbtn.setBounds(400, 450, 100, 40);
			bg.add(jpf);
			bg.add(jtf);
			bg.add(lgbtn);
			jf.setVisible(true);
			lgbtn.addActionListener(this);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
			JOptionPane.showMessageDialog(jf, "something is wrong may be the database", "Alert",
					JOptionPane.WARNING_MESSAGE);
		}

	}

	public static void main(String[] args) {
		new Admin();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == lgbtn) {
			String url = "jdbc:mysql://localhost:3306/CMS";
			String username = "root";
			String password = "root";
			Connection con = null;
			Statement st = null;
			try {
				con = DriverManager.getConnection(url, username, password);
				st = con.createStatement();
				ResultSet rs = st.executeQuery("select * from Admintable");
				String pas = null;
				String usn = null;
				if (rs.next()) {
					usn = rs.getString("username");
					pas = rs.getString("password");
				}
				con.close();
				st.close();
				String usfi, pasfi;
				usfi = jtf.getText();
				pasfi = new String(jpf.getPassword());
				if (usn.equals(usfi) && pasfi.equals(pas)) {
					jf.dispose();
					new MainApp();
				} else {
					JOptionPane.showMessageDialog(jf,
							"wrong username or password\n please use the correct username and password.", "Alert",
							JOptionPane.WARNING_MESSAGE);
				}
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(null, "something wents wrong can't connect to database.", "Alert",
						JOptionPane.WARNING_MESSAGE);
				System.out.println(ex);
			}

		} else if (e.getSource() == crbtn) {
			String us, cus, pa, cpa;
			us = usna.getText();
			cus = cusna.getText();
			pa = new String(pas.getPassword());
			cpa = new String(cpas.getPassword());
			if (us.equals(cus) && !us.equals("")) {
				if (pa.equals(cpa) && !pa.equals("")) {
					String url = "jdbc:mysql://localhost:3306/CMS";
					String username = "root";
					String password = "root";
					Connection con = null;
					PreparedStatement preparedStmt = null;
					try {
						con = DriverManager.getConnection(url, username, password);
						String query = "insert into Admintable values(?,?)";
						preparedStmt = con.prepareStatement(query);
						preparedStmt.setString(1, us);
						preparedStmt.setString(2, pa);
						preparedStmt.execute();
						preparedStmt.close();
						con.close();
						JOptionPane.showMessageDialog(mf, "creation success now you can login", "info",
								JOptionPane.INFORMATION_MESSAGE);
						mf.dispose();
						new Admin();

					} catch (Exception e2) {
						// TODO: handle exception
					}

				} else {
					JOptionPane.showMessageDialog(mf, "password didn't match or it is empty please try again", "Alert",
							0);
				}

			} else {
				JOptionPane.showMessageDialog(mf, "username didn't match or it is empty please try again", "Alert", 0);
			}
		}
	}

}
