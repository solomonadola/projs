package astuclassmangementsystem;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

class Security implements ActionListener, MouseListener {
	MainWindow mf = new MainWindow();
	private JTextField ous, nus, nnus;
	private JPasswordField opas, npas, nnpas;
	private JButton upbtn;
	Home hm = new Home();
	private ImageIcon ic;
	private JLabel bg;

	public Security() {
		ic = new ImageIcon(getClass().getResource("security.png"));
		bg = new JLabel(ic);
		mf.add(bg);
		mf.setVisible(false);
		bg.setSize(800, 860);
		mf.remove(mf.jl);
		mf.repaint();

		ous = new JTextField("old username");
		opas = new JPasswordField("old password");
		nus = new JTextField("new username");
		nnus = new JTextField("confirm username");
		npas = new JPasswordField("new password");
		nnpas = new JPasswordField("confirm password");
		upbtn = new JButton("update");
		upbtn.setBounds(550, 650, 100, 40);
		ous.setBounds(342, 182, 305, 40);
		opas.setBounds(342, 260, 305, 40);
		nus.setBounds(342, 335, 305, 40);
		nnus.setBounds(342, 411, 305, 40);
		npas.setBounds(342, 488, 305, 40);
		nnpas.setBounds(342, 574, 305, 40);
		bg.add(ous);
		bg.add(opas);
		bg.add(nus);
		bg.add(nnus);
		bg.add(npas);
		bg.add(nnpas);
		bg.add(upbtn);
		bg.add(hm);
		mf.setVisible(true);
		hm.addActionListener(this);
		upbtn.addActionListener(this);
		ous.addMouseListener(this);
		opas.addMouseListener(this);
		npas.addMouseListener(this);
		nnpas.addMouseListener(this);
		nus.addMouseListener(this);
		nnus.addMouseListener(this);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == hm) {
			mf.dispose();
		}
		if (e.getSource() == upbtn) {
			String url = "jdbc:mysql://localhost:3306/CMS";
			String username = "root";
			String password = "root";
			Connection con = null;
			PreparedStatement preparedStmt = null;
			String usname = null, passwd = null;
			try {
				con = DriverManager.getConnection(url, username, password);
				preparedStmt = con.prepareStatement("select * from admintable");
				ResultSet rs = preparedStmt.executeQuery();
				while (rs.next()) {
					usname = rs.getString("username");
					passwd = rs.getString("password");
				}
				preparedStmt.close();
				con.close();
				if (ous.getText().equals(usname) && new String(opas.getPassword()).equals(passwd)) {
					if (nus.getText().equals(nnus.getText())) {
						if (new String(npas.getPassword()).equals(new String(nnpas.getPassword()))) {
							con = DriverManager.getConnection(url, username, password);
							preparedStmt = con.prepareStatement(
									"update admintable set username=?, password=? where username=?and password=?");
							preparedStmt.setString(1, nus.getText());
							preparedStmt.setString(2, new String(npas.getPassword()));
							preparedStmt.setString(3, ous.getText());
							preparedStmt.setString(4, new String(opas.getPassword()));
							preparedStmt.execute();
							preparedStmt.executeUpdate();
							preparedStmt.close();
							JOptionPane.showMessageDialog(mf, "your username and password updated successfully!!!!!!!",
									"info", JOptionPane.INFORMATION_MESSAGE);
							mf.dispose();
							new MainApp();
						} else {
							JOptionPane.showMessageDialog(mf, "new password didn't match please check and correct it",
									"info", JOptionPane.WARNING_MESSAGE);

						}
					} else
						JOptionPane.showMessageDialog(mf, "new username didn't match please check and correct it",
								"info", JOptionPane.WARNING_MESSAGE);

				} else {
					JOptionPane.showMessageDialog(mf,
							"wrong old password or username !!!!!\nplease fill the correct password and username",
							"info", JOptionPane.WARNING_MESSAGE);

				}
				con.close();

			}

			catch (Exception exd) {
				JOptionPane.showMessageDialog(mf, "something is wrong with database can't connect with database",
						"info", JOptionPane.WARNING_MESSAGE);
			}

		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == ous) {
			ous.setText("");
			ous.removeMouseListener(this);
		}
		if (e.getSource() == opas) {
			opas.setText(null);
			opas.removeMouseListener(this);

		}
		if (e.getSource() == nus) {
			nus.setText(null);
			nus.removeMouseListener(this);

		}
		if (e.getSource() == nnus) {
			nnus.setText(null);
			nnus.removeMouseListener(this);

		}
		if (e.getSource() == npas) {
			npas.setText(null);
			npas.removeMouseListener(this);

		}
		if (e.getSource() == nnpas) {
			nnpas.setText(null);
			nnpas.removeMouseListener(this);

		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}
}
