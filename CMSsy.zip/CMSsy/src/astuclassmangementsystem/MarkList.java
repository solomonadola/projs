package astuclassmangementsystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class MarkList implements ActionListener {
	MainWindow mf = new MainWindow();
	JTable mrli;
	JScrollPane jsp = new JScrollPane(mrli);
	private JButton upbtn;
	private String url = "jdbc:mysql://localhost:3306/CMS";
	private String username = "root";
	private String password = "root";
	private Connection con = null;
	private Statement st = null;
	private PreparedStatement pst = null;
	Home hm = new Home();

	public MarkList() {
		mrli = new JTable(41, 7) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int row, int column) {
				if (column == 0 || column == 1 || column == 2 || row == 0)
					return false;
				return true;
			}
		};
		mrli.getColumnModel().getColumn(0).setPreferredWidth(5);
		mrli.getColumnModel().getColumn(1).setPreferredWidth(250);
		mrli.getColumnModel().getColumn(2).setPreferredWidth(80);
		mrli.getColumnModel().getColumn(3).setPreferredWidth(5);
		mrli.getColumnModel().getColumn(4).setPreferredWidth(5);
		mrli.getColumnModel().getColumn(5).setPreferredWidth(5);
		mrli.getColumnModel().getColumn(6).setPreferredWidth(5);
		mrli.setFont(new Font("serif", Font.PLAIN, 20));
		int i = 1;
		while (i <= 40) {
			mrli.setValueAt(i, i, 0);
			i++;
		}
		mrli.setBounds(0, 0, 800, 860);
		mrli.setAutoResizeMode(4);
		mrli.setBackground(Color.black.darker());
		mrli.setForeground(Color.white.brighter());
		mrli.setFont(new Font("arial", Font.BOLD, 13));
		mrli.setValueAt("No", 0, 0);
		mrli.setValueAt("Name", 0, 1);
		mrli.setValueAt("Id", 0, 2);
		mrli.setValueAt("Quiz", 0, 3);
		mrli.setValueAt("Assignment", 0, 4);
		mrli.setValueAt("Mid-exam", 0, 5);
		mrli.setValueAt("Final-exam", 0, 6);
		upbtn = new JButton("update");
		upbtn.setBounds(680, 700, 100, 40);
		mf.jl.add(hm);
		mf.jl.add(upbtn);
		mf.jl.add(mrli);
		mf.jl.add(jsp);
		hm.addActionListener(this);
		upbtn.addActionListener(this);

		try {
			con = DriverManager.getConnection(url, username, password);
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from studenttable order by name");
			int k = 0;
			while (rs.next()) {
				k++;
				mrli.setValueAt(rs.getString("name"), k, 1);
				mrli.setValueAt(rs.getString("id"), k, 2);
				mrli.setValueAt(rs.getString("quiz"), k, 3);
				mrli.setValueAt(rs.getString("assignment"), k, 4);
				mrli.setValueAt(rs.getString("mid"), k, 5);
				mrli.setValueAt(rs.getString("final"), k, 6);

			}
			con.close();
			st.close();
			rs.close();
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "something wents wrong can't connect to database.", "Alert",
					JOptionPane.WARNING_MESSAGE);
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == upbtn) {
			try {
				con = DriverManager.getConnection(url, username, password);
				pst = con.prepareStatement("update studenttable set quiz=?, assignment=?, mid=?,final=? where id=? ");
				int y = 1;
				while (mrli.getValueAt(y, 0) != null) {
					if (mrli.getValueAt(y, 2) == null) {
						break;
					}
					pst.setString(1, (String) mrli.getValueAt(y, 3));
					pst.setString(2, (String) mrli.getValueAt(y, 4));
					pst.setString(3, (String) mrli.getValueAt(y, 5));
					pst.setString(4, (String) mrli.getValueAt(y, 6));
					pst.setString(5, (String) mrli.getValueAt(y, 2));
					y++;
					pst.execute();

				}

				con.close();
				pst.close();
			} catch (Exception ex) {
				System.out.println(ex);
				JOptionPane.showMessageDialog(null, "something wents wrong can't connect to database.", "Alert",
						JOptionPane.WARNING_MESSAGE);
			}
		}
		if (e.getSource() == hm) {
			mf.dispose();
		}
	}

}
