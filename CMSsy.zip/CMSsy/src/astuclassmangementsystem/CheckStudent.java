package astuclassmangementsystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

class CheckStudent implements ActionListener, MouseListener{
	MainWindow mf = new MainWindow();
	private JTextField df = new JTextField("id or full name to check");
	JTable cht = new JTable(10, 6);
	Home hm = new Home();
	private JButton ckbtn = new JButton("check");

	public CheckStudent() {

		df.setBounds(250, 300, 300, 40);
		df.setForeground(Color.red);
		df.setFont(new Font("arial", Font.BOLD, 18));
		ckbtn.setBounds(350, 380, 104, 40);
		cht.setBounds(0, 0, 800, 860);
		cht.setValueAt("name", 0, 0);
		cht.setValueAt("id", 0, 1);
		cht.setValueAt("sex", 0, 2);
		cht.setValueAt("department", 0, 3);
		cht.setValueAt("absent day", 0, 4);
		cht.setValueAt("total mark", 0, 5);
		mf.jl.add(df);
		mf.jl.add(ckbtn);
		mf.jl.add(hm);
		ckbtn.addActionListener(this);
		hm.addActionListener(this);
		df.addMouseListener(this);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == hm) {
			mf.dispose();
		}
		if (e.getSource() == ckbtn) {
			String url = "jdbc:mysql://localhost:3306/CMS";
			String username = "root";
			String password = "root";
			Connection con = null;
			PreparedStatement preparedStmt = null;
			try {
				con = DriverManager.getConnection(url, username, password);
				preparedStmt = con.prepareStatement("select * from studenttable where id=? or name=?");
				preparedStmt.setString(1, df.getText());
				preparedStmt.setString(2, df.getText());
				ResultSet rs = preparedStmt.executeQuery();

				int i = 0;
				while (rs.next()) {
					i++;
					cht.setValueAt(rs.getString(1), i, 0);
					cht.setValueAt(rs.getString(2), i, 1);
					cht.setValueAt(rs.getString(3), i, 2);
					cht.setValueAt(rs.getString(4), i, 3);
					cht.setValueAt(rs.getString(13), i, 4);
				}

				if (i > 0) {

					MainWindow mfF = new MainWindow();
					mf.dispose();
					mfF.add(cht);
				}
				preparedStmt.close();
				rs.close();
				con.close();

			} catch (Exception ex) {
				JOptionPane.showMessageDialog(null, "something wents wrong can't connect to database.", "Alert",
						JOptionPane.WARNING_MESSAGE);
			}
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		df.setText(null);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
