package astuclassmangementsystem;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;

class Home extends JButton implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ImageIcon ic = new ImageIcon(getClass().getResource("home.png"));

	Home() {
		super();
		setIcon(ic);
		setBounds(360, 700, 110, 40);
		addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		new MainApp();
	}

}
