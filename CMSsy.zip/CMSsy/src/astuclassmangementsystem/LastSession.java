package astuclassmangementsystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

class LastSession implements ActionListener {
	MainWindow mf = new MainWindow();
	private JTextArea jtf = new JTextArea();
	private JTextArea jlf = new JTextArea();
	private JLabel jlff = new JLabel("last class");
	private JLabel jlfa = new JLabel("Add your Last session of this class down here");
	private JButton lasbtn = new JButton("update");
	private String gt;
	Home hm = new Home();

	public LastSession() {
		jlf.setEditable(false);
		jlf.setBackground(Color.GRAY.brighter());
		jlff.setBounds(100, 80, 100, 40);
		jlf.setBounds(100, 120, 600, 200);
		jlfa.setBounds(100, 365, 400, 40);
		jlff.setForeground(Color.GREEN.brighter());
		jlff.setFont(new Font("arial", Font.BOLD, 20));
		jlf.setForeground(Color.BLUE.brighter());
		jlfa.setForeground(Color.RED.brighter());
		jlf.setFont(new Font("arial", Font.BOLD, 18));
		jlfa.setFont(new Font("arial", Font.BOLD, 18));
		jtf.setBounds(100, 400, 600, 200);
		jtf.setFont(new Font("arial", Font.BOLD, 18));
		lasbtn.setBounds(550, 650, 100, 40);
		mf.jl.add(jlf);
		mf.jl.add(jtf);
		mf.jl.add(lasbtn);
		mf.jl.add(jlfa);
		mf.jl.add(jlff);
		lasbtn.addActionListener(this);
		String url = "jdbc:mysql://localhost:3306/CMS";
		String username = "root";
		String password = "root";
		Connection con = null;
		Statement st = null;
		String ss = null;
		gt = jtf.getText();
		mf.jl.add(hm);
		hm.addActionListener(this);

		try {
			con = DriverManager.getConnection(url, username, password);
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from lastsession");
			while (rs.next()) {

				ss = rs.getString("las");
			}

			jlf.setText(ss);

			st.close();
			con.close();
		} catch (Exception exd) {
			JOptionPane.showMessageDialog(mf, "something is wrong with database can't connect with database", "info",
					JOptionPane.WARNING_MESSAGE);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == hm) {
			mf.dispose();
		}
		if (e.getSource() == lasbtn) {
			String url = "jdbc:mysql://localhost:3306/CMS";
			String username = "root";
			String password = "root";
			Connection con = null;
			PreparedStatement preparedStmt = null;
			if (jtf.getText().equals(gt)) {
				JOptionPane.showMessageDialog(mf, "nothing to update you must fill the text to update", "info",
						JOptionPane.WARNING_MESSAGE);
			} else {
				try {
					con = DriverManager.getConnection(url, username, password);
					String query = " insert into lastsession values (?)";

					preparedStmt = con.prepareStatement(query);
					preparedStmt.setString(1, jtf.getText());
					preparedStmt.execute();
					preparedStmt.close();
					con.close();
					JOptionPane.showMessageDialog(mf, "update success", "info", JOptionPane.INFORMATION_MESSAGE);

				}

				catch (Exception exd) {
					JOptionPane.showMessageDialog(mf, "something is wrong with database can't connect with database",
							"info", JOptionPane.WARNING_MESSAGE);
				}
			}

		}
	}

}
