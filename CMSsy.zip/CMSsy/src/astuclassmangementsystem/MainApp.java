package astuclassmangementsystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class MainApp implements ActionListener {
	MainWindow mf;
	private JButton atbtn, mrbtn, stibtn, secbtn, regbtn, dbtn, lasbtn, ckstbtn, qbtn;

	public MainApp() {
		mf = new MainWindow();
		atbtn = new JButton("Attendance");
		mrbtn = new JButton("Mark-list");
		stibtn = new JButton("Student-info");
		secbtn = new JButton("Security");
		regbtn = new JButton("Registration");
		dbtn = new JButton("Delete");
		lasbtn = new JButton("Last session");
		ckstbtn = new JButton("check student");
		stibtn.setBackground(Color.orange);
		stibtn.setForeground(new Color(123, 2, 12));
		stibtn.setFont(new Font("arial",Font.BOLD,15));
		secbtn.setBackground(Color.orange);
		secbtn.setForeground(new Color(123, 2, 12));
		secbtn.setFont(new Font("arial",Font.BOLD,15));
		regbtn.setBackground(Color.orange);
		regbtn.setForeground(new Color(123, 2, 12));
		regbtn.setFont(new Font("arial",Font.BOLD,15));
		dbtn.setBackground(Color.orange);
		dbtn.setForeground(new Color(123, 2, 12));
		dbtn.setFont(new Font("arial",Font.BOLD,15));
		lasbtn.setBackground(Color.orange);
		lasbtn.setForeground(new Color(123, 2, 12));
		lasbtn.setFont(new Font("arial",Font.BOLD,15));
		ckstbtn.setBackground(Color.orange);
		ckstbtn.setForeground(new Color(123, 2, 12));
		ckstbtn.setFont(new Font("arial",Font.BOLD,15));
		ImageIcon ic = new ImageIcon(getClass().getResource("exit.png"));
		qbtn = new JButton(ic);
		atbtn.setBackground(Color.orange);
		atbtn.setForeground(new Color(123, 2, 12));
		atbtn.setFont(new Font("arial",Font.BOLD,15));
		mrbtn.setBackground(Color.orange);
		mrbtn.setForeground(new Color(123, 2, 12));
		mrbtn.setFont(new Font("arial",Font.BOLD,15));
		qbtn.setBounds(350, 650, 100, 40);
		qbtn.setForeground(Color.WHITE.brighter());
		qbtn.setBackground(Color.RED.brighter());
		ckstbtn.setBounds(415, 200, 130, 40);
		lasbtn.setBounds(265, 200, 130, 40);
		dbtn.setBounds(115, 200, 130, 40);
		regbtn.setBounds(565, 100, 130, 40);
		secbtn.setBounds(565, 200, 130, 40);
		stibtn.setBounds(415, 100, 130, 40);
		mrbtn.setBounds(265, 100, 130, 40);
		atbtn.setBounds(115, 100, 130, 40);
		mf.jl.add(atbtn, null);
		mf.jl.add(mrbtn);
		mf.jl.add(regbtn);
		mf.jl.add(dbtn);
		mf.jl.add(ckstbtn, null);
		mf.jl.add(stibtn);
		mf.jl.add(lasbtn);
		mf.jl.add(secbtn);
		mf.jl.add(qbtn);
		mf.repaint();
		atbtn.addActionListener(this);
		mrbtn.addActionListener(this);
		stibtn.addActionListener(this);
		secbtn.addActionListener(this);
		regbtn.addActionListener(this);
		dbtn.addActionListener(this);
		lasbtn.addActionListener(this);
		ckstbtn.addActionListener(this);
		qbtn.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == atbtn) {
			mf.dispose();
			new Attendance();
		} else if (e.getSource() == stibtn) {
			mf.dispose();
			StudentInfo stf = new StudentInfo();
			String url = "jdbc:mysql://localhost:3306/CMS";
			String username = "root";
			String password = "root";
			Connection con = null;
			Statement st = null;
			try {
				con = DriverManager.getConnection(url, username, password);
				st = con.createStatement();
				ResultSet rs = st.executeQuery("select * from studenttable order by name");
				int i = 0;
				while (rs.next()) {
					i++;
					int x = rs.getInt(9) + rs.getInt(10) + rs.getInt(11) + rs.getInt(12);
					stf.att.setValueAt(rs.getString(1), i, 1);
					stf.att.setValueAt(rs.getString(2), i, 2);
					stf.att.setValueAt(rs.getString("attendance"), i, 3);
					stf.att.setValueAt(x, i, 4);

				}

				st.close();
				rs.close();
				con.close();

			}

			catch (Exception ex) {
				System.out.println(ex);
				JOptionPane.showMessageDialog(null, "something wents wrong can't connect to database.", "Alert",
						JOptionPane.WARNING_MESSAGE);
			}
		} else if (e.getSource() == regbtn) {
			mf.dispose();
			new Registration();
		} else if (e.getSource() == mrbtn) {
			mf.dispose();
			new MarkList();
		} else if (e.getSource() == dbtn) {
			mf.dispose();
			new Delete();
		} else if (e.getSource() == ckstbtn) {
			mf.dispose();
			new CheckStudent();
		} else if (e.getSource() == lasbtn) {
			mf.dispose();
			new LastSession();
		} else if (e.getSource() == secbtn) {
			mf.dispose();
			new Security();
		} else if (e.getSource() == qbtn) {
			System.exit(1);
		}
	}
}